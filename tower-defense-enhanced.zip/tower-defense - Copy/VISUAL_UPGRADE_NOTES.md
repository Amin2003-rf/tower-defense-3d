# Tower Defense 3D — visual update notes

This update keeps the existing game rules, tower statistics, enemy statistics, wave progression, and controls unchanged.

## Visual and animation changes

- Tower aiming now uses frame-rate-independent exponential easing to reduce visible stepping while tracking moving targets.
- Tower firing has a short backward mechanical recoil and a brief muzzle-flash scale animation.
- Tower bases have a metallic rim and four small fasteners for extra model detail.
- Enemy turning uses frame-rate-independent easing.
- Burning enemy effects use deterministic flame movement instead of random size changes every frame, reducing visual jitter.
- Mobile rendering resolution is capped more conservatively to help maintain steadier frame pacing on mid-range phones.
- UI touch feedback, button transitions, and tower thumbnails have subtle depth and polish improvements.

## Build notes

The uploaded archive contained only a partial generated `android/` directory: it did not include the Gradle wrapper, Android root Gradle files, or the native `MainActivity`. Therefore, a finished APK could not be compiled in this environment. The GitHub Actions workflow was updated to generate a clean Capacitor Android project in the cloud and upload a debug APK as an artifact. See `MOBILE_SETUP.md` for the steps.
