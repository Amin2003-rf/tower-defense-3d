# Tower Defense 3D / دفاع از برج سه‌بعدی

Pure HTML + ES modules + Three.js. The Node.js service serves the game and hosts the internet multiplayer WebSocket relay.

## Run / اجرا
**Run locally (single-player and local development):**
```
node server/server.js        # or: npm start, start.sh (Linux/macOS), start.bat (Windows)
```
Open `http://localhost:8080`. For internet multiplayer, deploy the service using [`render.yaml`](render.yaml) and follow [DEPLOY_INTERNET.md](DEPLOY_INTERNET.md).

Single player only (no Node): serve the folder with any static server, e.g. `python3 -m http.server 8000`
(opening `index.html` directly from disk does not work: browsers block ES modules on `file://`).
An internet connection is needed once for Three.js and the Vazirmatn font (CDN).

## Game modes / حالت‌ها
* **Campaign** – 6 chapters, 19 stages, each with its own map, enemies and unlocks (stage 1 teaches the basics, cannon only).
* **Endless** – every tower, spell and enemy is available; Easy / Normal / Hard; best wave is stored per difficulty.
* **Multiplayer (co-op, 2-4 players)** – same map, one shared base and gold treasury, anyone can build/upgrade/sell/cast.

## Multiplayer (internet co-op)
1. Deploy the Node.js service using [`render.yaml`](render.yaml) and the steps in [DEPLOY_INTERNET.md](DEPLOY_INTERNET.md).
2. Copy the deployed HTTPS host name (for example, `your-service.onrender.com`).
3. In the game, open **Multiplayer** and enter that host name in **Internet server address**. The app connects using secure WSS.
4. The host creates a room and shares its four-letter code. Other players enter the same server address and join with that code.
5. The host chooses a map and difficulty, then starts the match. Up to four players can join.

Architecture: the host browser runs the game simulation and sends snapshots 15 times per second through the hosted relay; other players mirror the state and send their build, upgrade, sell and spell commands to the host.

## Controls
Tap a glowing plot → circle opens → tap a tower (range preview) → tap the ✔ to build. Tap a tower: ⬆️ upgrade (green arrows show the gain), 💰 sell.
Mouse wheel / pinch / ＋－ buttons zoom, drag to pan when zoomed. ⚙️ settings (language, theme, sound, graphics quality, speed).
Everything is saved in `localStorage` (keys start with `td_`); "Forget all saved data" in the main menu wipes it.

## Project structure
```
tower-defense/
├─ index.html            page, menus, import map (Three.js + add-ons)
├─ css/                  style.css (layout, HUD, menus, motion), themes.css (dark/light variables)
├─ js/
│  ├─ main.js            bootstrap, input (tap/pan/pinch/wheel), game loop
│  ├─ config.js          towers, enemies, elements, chapters/stages, endless difficulties, waves, sounds
│  ├─ game.js            Game: state, economy, waves, spells, destruction, hazards
│  ├─ enemy.js tower.js projectile.js soldier.js special.js   entities (models + behaviour)
│  ├─ grid.js decor.js textures.js ambient.js scene3d.js     map, scenery, procedural textures, particles, renderer (PBR + bloom)
│  ├─ ui.js              menus, radial build menu, panels, lobby
│  ├─ net.js             multiplayer: Net (connection), NetHost (authoritative host), RemoteGame (client view)
│  ├─ save.js i18n.js audio.js thumbs.js                     progress, FA/EN texts, Web Audio, model previews
├─ server/server.js      zero-dependency static server + WebSocket relay (rooms of up to 4)
├─ assets/               (nothing needed: all content is procedural)
└─ package.json start.sh start.bat README.md
```

## Mobile app (Capacitor)

The project now includes an initial Capacitor scaffold for Android and iOS. See [`MOBILE_SETUP.md`](MOBILE_SETUP.md) for prerequisites and commands. Run `npm install`, then `npm run build:web` to create the local mobile bundle in `www/`; Three.js is copied into that bundle instead of being loaded from a CDN.

**Important:** the Android app does not run the Node.js multiplayer server itself. Internet multiplayer requires the separately deployed server URL to be entered once in the multiplayer screen; it is saved on that device.
