// Tower Defense 3D: internet multiplayer WebSocket relay + static game server.
// Production deployment: Render (or another Node host) terminates HTTPS/WSS in front of this HTTP server.
// Start: npm start
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = Number(process.env.PORT) || 8080;
const MAX_PLAYERS = 4;
const MAX_FRAME = 1_000_000;
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json'
};

const server = http.createServer((req, res) => {
  const pathname = (req.url || '/').split('?')[0];
  if (pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ ok: true, service: 'tower-defense-3d', rooms: rooms.size }));
  }
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { res.writeHead(400); return res.end('Bad request'); }
  if (decoded === '/') decoded = '/index.html';
  const file = path.resolve(ROOT, '.' + decoded);
  if (!file.startsWith(ROOT + path.sep) || file.startsWith(path.join(ROOT, 'server') + path.sep)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  });
});

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function frame(payload, opcode = 1) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  const n = body.length;
  let head;
  if (n < 126) head = Buffer.from([0x80 | opcode, n]);
  else if (n < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(n, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([head, body]);
}
const send = (client, data, opcode = 1) => { if (!client.socket.destroyed) client.socket.write(frame(data, opcode)); };
const sendJSON = (client, value) => send(client, JSON.stringify(value));

function parseFrames(client) {
  while (true) {
    const buffer = client.buffer;
    if (buffer.length < 2) return;
    const fin = !!(buffer[0] & 0x80);
    const opcode = buffer[0] & 0x0f;
    const masked = !!(buffer[1] & 0x80);
    let length = buffer[1] & 0x7f;
    let offset = 2;
    if (length === 126) { if (buffer.length < 4) return; length = buffer.readUInt16BE(2); offset = 4; }
    else if (length === 127) { if (buffer.length < 10) return; const big = buffer.readBigUInt64BE(2); if (big > BigInt(MAX_FRAME)) return client.socket.destroy(); length = Number(big); offset = 10; }
    if (length > MAX_FRAME) return client.socket.destroy();
    if (masked) offset += 4;
    if (buffer.length < offset + length) return;
    const payload = Buffer.from(buffer.subarray(offset, offset + length));
    if (masked) { const mask = buffer.subarray(offset - 4, offset); for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3]; }
    client.buffer = buffer.subarray(offset + length);
    if (opcode === 8) { client.socket.end(); return; }
    if (opcode === 9) { send(client, payload, 10); continue; }
    if (opcode === 10) continue;
    if (opcode === 1 || opcode === 2) client.fragments = [payload];
    else if (opcode === 0) client.fragments.push(payload);
    else continue;
    if (!fin) continue;
    const message = Buffer.concat(client.fragments).toString('utf8');
    client.fragments = [];
    try { handleMessage(client, message); } catch (error) { console.error('WebSocket message error:', error); }
  }
}

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if ((req.url || '').split('?')[0] !== '/ws' || !key || req.headers.upgrade?.toLowerCase() !== 'websocket') {
    socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n'); return socket.destroy();
  }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const client = { socket, buffer: Buffer.alloc(0), fragments: [], room: null, id: -1, name: '' };
  socket.on('data', chunk => { client.buffer = Buffer.concat([client.buffer, chunk]); parseFrames(client); });
  socket.on('close', () => leaveRoom(client));
  socket.on('error', () => socket.destroy());
});

const rooms = new Map();
const cleanName = value => String(value || 'Player').replace(/[<>&"']/g, '').trim().slice(0, 14) || 'Player';
function makeCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  for (;;) {
    let code = '';
    for (let i = 0; i < 4; i++) code += alphabet[crypto.randomInt(alphabet.length)];
    if (!rooms.has(code)) return code;
  }
}
const roster = room => room.players.map(player => ({ id: player.id, name: player.name }));
const broadcastLobby = room => room.players.forEach(player => sendJSON(player, { t: 'lobby', code: room.code, started: room.started, players: roster(room) }));
function leaveRoom(client) {
  const room = client.room;
  if (!room) return;
  client.room = null;
  room.players = room.players.filter(player => player !== client);
  if (client.id === 0) {
    room.players.forEach(player => { sendJSON(player, { t: 'closed' }); player.room = null; });
    rooms.delete(room.code);
    return;
  }
  const host = room.players.find(player => player.id === 0);
  if (host) sendJSON(host, { t: 'left', id: client.id });
  if (!room.started) broadcastLobby(room);
}
function handleMessage(client, raw) {
  let message;
  try { message = JSON.parse(raw); } catch { return; }
  if (!message || typeof message.t !== 'string') return;
  const room = client.room;
  switch (message.t) {
    case 'create': {
      leaveRoom(client);
      const next = { code: makeCode(), players: [client], started: false };
      rooms.set(next.code, next); client.room = next; client.id = 0; client.name = cleanName(message.name);
      sendJSON(client, { t: 'created', code: next.code, id: 0 }); broadcastLobby(next); break;
    }
    case 'join': {
      leaveRoom(client);
      const target = rooms.get(String(message.code || '').toUpperCase().trim());
      if (!target) return sendJSON(client, { t: 'err', msg: 'noroom' });
      if (target.started) return sendJSON(client, { t: 'err', msg: 'started' });
      if (target.players.length >= MAX_PLAYERS) return sendJSON(client, { t: 'err', msg: 'full' });
      let id = 1; while (target.players.some(player => player.id === id)) id++;
      client.room = target; client.id = id; client.name = cleanName(message.name); target.players.push(client);
      sendJSON(client, { t: 'joined', code: target.code, id }); broadcastLobby(target); break;
    }
    case 'start':
      if (room && client.id === 0 && !room.started) {
        const map = Number(message.cfg?.map), diff = String(message.cfg?.diff || 'normal');
        if (!Number.isInteger(map) || map < 0 || map > 18 || !['easy', 'normal', 'hard'].includes(diff)) return;
        room.started = true;
        const packet = { t: 'start', cfg: { map, diff }, players: roster(room) };
        room.players.forEach(player => sendJSON(player, packet));
      }
      break;
    case 'cmd':
      if (room && client.id !== 0 && !room.started) return;
      if (room && client.id !== 0) { const host = room.players.find(player => player.id === 0); if (host) sendJSON(host, { t: 'cmd', from: client.id, d: message.d }); }
      break;
    case 's':
      if (room && client.id === 0 && room.started) room.players.forEach(player => { if (player !== client) send(player, raw); });
      break;
  }
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Tower Defense 3D server listening on port ${PORT}`);
  console.log('HTTP health check: /health | WebSocket endpoint: /ws');
});
